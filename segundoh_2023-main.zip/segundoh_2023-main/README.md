# segundoh_2023
Projeto do João Pedro n°16 e da Lívia n°22

tema: Depressão entre alunos do Ensino Médio.
Descrição: Um site que propõe a disponibilização de materiais promovendo a conscientização e prevenção da depressão em adolescêntes. O site permitirá que a comunidade escolar tenha mais conhecimento sobre o transtorno; acredita-se que 
